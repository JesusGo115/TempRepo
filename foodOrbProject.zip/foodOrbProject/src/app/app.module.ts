import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';


import { FormsModule } from '@angular/forms';
import { HomeComponent } from './components/home/home.component';
import { CartComponent } from './components/cart/cart.component';
import { ErrorComponent } from './components/error/error.component';
import { LoginComponent } from './components/login/login.component';
import { ProfileComponent } from './components/profile/profile.component';
import { RegisterComponent } from './components/register/register.component';
import { ResetPassComponent } from './components/reset-pass/reset-pass.component';
import { SettingsComponent } from './components/settings/settings.component';
import { TrackingComponent } from './components/tracking/tracking.component';
import { ItemsService } from './services/items.service';
import { AddressComponent } from './components/address/address.component';
import { CardComponent } from './components/card/card.component';
import { FilterPipe } from './pipe/filter.pipe';
import { HighlightDirective } from './directive/highlight.directive';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CartComponent,
    ErrorComponent,
    LoginComponent,
    ProfileComponent,
    RegisterComponent,
    ResetPassComponent,
    SettingsComponent,
    TrackingComponent,
    AddressComponent,
    CardComponent,
    FilterPipe,
    HighlightDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [ItemsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
