import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddressComponent } from './components/address/address.component';
import { CardComponent } from './components/card/card.component';
import { CartComponent } from './components/cart/cart.component';
import { ErrorComponent } from './components/error/error.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { ProfileComponent } from './components/profile/profile.component';
import { RegisterComponent } from './components/register/register.component';
import { ResetPassComponent } from './components/reset-pass/reset-pass.component';
import { SettingsComponent } from './components/settings/settings.component';
import { TrackingComponent } from './components/tracking/tracking.component';

const routes: Routes = [

  {
    path: '',
    component: LoginComponent
  },
  {
    path: 'home',
    component: HomeComponent

  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: 'resetPass',
    component: ResetPassComponent

  },
  {
    path: 'settings',
    component: SettingsComponent
  },
  {
    path: 'profile',
    component: ProfileComponent

  },
  {
    path: 'cart',
    component: CartComponent

  },
  {
    path: 'track',
    component: TrackingComponent
  },
  {
    path: 'card',
    component: CardComponent

  },
  {
    path: 'address',
    component: AddressComponent
  },
  {
    path: 'not-found',
    component: ErrorComponent, data: { message: 'Page not found!' }
  },
  {
    path: '**',
    redirectTo: '/not-found',
    pathMatch: 'full'
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
