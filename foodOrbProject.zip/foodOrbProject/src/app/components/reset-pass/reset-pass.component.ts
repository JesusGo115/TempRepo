import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reset-pass',
  templateUrl: './reset-pass.component.html',
  styleUrls: ['./reset-pass.component.css']
})
export class ResetPassComponent implements OnInit {

  registerForm: FormGroup = this._formBuilder.group({});

  submitted = false;

  constructor(private _formBuilder: FormBuilder) { }

  ngOnInit(): void {

    this.registerForm = this._formBuilder.group({
          email: ['', [Validators.required, Validators.email]]
      }

    );

  }

  get f() { return this.registerForm?.controls; }

  checkRequiredValidation(control: string) {
    return this.f[control].errors?.['required'];
  }

  checkEmailFormat(control: string) {
    return this.f[control].errors?.['email'];
  }


  onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            console.log(this.registerForm);
            return;
        }

        // display form values on success
        // alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));

        window.location.href = "/";
    }

}
