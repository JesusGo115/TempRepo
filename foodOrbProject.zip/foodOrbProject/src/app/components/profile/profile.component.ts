import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  user: any;

  id: any;

  constructor(
    private _userService: UsersService,
    private _activatedRoute: ActivatedRoute,
    private router: Router
  ) {
    this.user = _userService.getUsersById(1);
  }

  ngOnInit(): void {

    this.id = this._activatedRoute.snapshot.paramMap.get('id');

    this.user = this._userService.getUsersById(1);

  }

}
