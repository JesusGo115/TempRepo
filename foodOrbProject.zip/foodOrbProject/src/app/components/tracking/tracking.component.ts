import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TrackingInfoService } from 'src/app/services/tracking-info.service';

@Component({
  selector: 'app-tracking',
  templateUrl: './tracking.component.html',
  styleUrls: ['./tracking.component.css']
})
export class TrackingComponent implements OnInit {

  orderList: any = [];

  constructor(
    private _trackingService: TrackingInfoService,
    private _activatedRoute: ActivatedRoute) {

      this.orderList = this._trackingService.getOrders();

    }

  ngOnInit(): void {
    if (this._activatedRoute) {
      this._activatedRoute.queryParams.subscribe(
        (params: any) => {
          const { category } = params;
          this.orderList = this._trackingService.getOrders();
        }
      )
    }
  }

}
