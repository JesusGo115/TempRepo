import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ItemsService } from 'src/app/services/items.service';
import { FilterPipe } from 'src/app/pipe/filter.pipe';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  itemList: any = [];

  searchText = '';

  constructor(
    private _itemService: ItemsService,
    private _activatedRoute: ActivatedRoute) {

      this.itemList = this._itemService.getItems();

    }

  ngOnInit(): void {
    if (this._activatedRoute) {
      this._activatedRoute.queryParams.subscribe(
        (params: any) => {
          const { category } = params;
          this.itemList = this._itemService.getItems();
        }
      )
    }
  }

}
