import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CardsService } from 'src/app/services/cards.service';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

  registerForm: FormGroup = this._formBuilder.group({});

  submitted = false;

  cardList: any = []

  constructor(private _formBuilder: FormBuilder,
    private _addressService: CardsService,
    private _activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {

    this.registerForm = this._formBuilder.group({
          cardInfo: ['', Validators.required],
          expiration: ['', Validators.required],
          securityCode: ['', Validators.required]
      }

    );

    if (this._activatedRoute) {
      this._activatedRoute.queryParams.subscribe(
        (params: any) => {
          const { category } = params;
          this.cardList = this._addressService.getCards();
        }
      )
    }

  }

  get f() { return this.registerForm?.controls; }

  checkRequiredValidation(control: string) {
    return this.f[control].errors?.['required'];
  }

  checkEmailFormat(control: string) {
    return this.f[control].errors?.['email'];
  }

  checkMinLength(control: string) {
    return this.f[control].errors?.['minlength'];
  }

  checkMaxLength(control: string) {
    return this.f[control].errors?.['maxlength'];
  }

  checkMustMatchValidation(control: string) {
    return this.f[control].errors?.['mustMatch'];
  }

  mustMatch(pwd1: string, pwd2: string) {
    return (formGroup: FormGroup) => {
      const pwdControl = formGroup.controls[pwd1];
      const cnfPwdControl = formGroup.controls[pwd2];
      const existingErrors = cnfPwdControl.errors;
      // logic to match the values in both the fields
      if (pwdControl.value !== cnfPwdControl.value) {
        cnfPwdControl.setErrors({
          ...existingErrors,
          mustMatch: true

        });
      } else {
        cnfPwdControl.setErrors({
          ...existingErrors,
          mustMatch: false
        });
      }
    }
  }

  onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            console.log(this.registerForm);
            return;
        }

        // display form values on success
        // alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));

        window.location.href = "/settings";
    }

}
