import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ItemsService } from 'src/app/services/items.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  itemList: any = [];

  id: any;

  constructor(private _itemService: ItemsService,
    private _activatedRoute: ActivatedRoute) {

      this.itemList = this._itemService.getItems();

    }

  ngOnInit(): void {

    if (this._activatedRoute) {

      this._activatedRoute.queryParams.subscribe(
        (params: any) => {
          const { category } = params;
          this.itemList = this._itemService.getItems();
        }
      )
    }
  }

}
