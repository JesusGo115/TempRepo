import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ItemsService {

  item: any;

  items: any[] = [
    { id: 1, name: "Creamy Garlic Chicken", price: 6.99, img: "https://www.saltandlavender.com/wp-content/uploads/2018/12/creamy-garlic-chicken-recipe-3.jpg" },
    { id: 2, name: "FireCracker Chicken", price: 8.99, img: "https://www.dinneratthezoo.com/wp-content/uploads/2017/10/firecracker-chicken-1.jpg"  },
    { id: 3, name: "Crispy Fried Chicken", price: 7.99, img: "https://www.tasteofhome.com/wp-content/uploads/2018/01/Crispy-Fried-Chicken_EXPS_FRBZ19_6445_C01_31_3b-3.jpg?fit=700,1024" },
    { id: 4, name: "Teriyaki Grilled Salmon Rice Bowl", price: 10.99, img: "https://www.aheadofthyme.com/wp-content/uploads/2020/06/teriyaki-grilled-salmon-rice-bowl-7.jpg"  }
  ]

  constructor() { }

  getItems() {
    return this.items;
  }

  getItemsById(id: any) {

    this.item = this.items.find(item => item.id == id);

    console.log(this.item);

    return this.item;
  }

}
