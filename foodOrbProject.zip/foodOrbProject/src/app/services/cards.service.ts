import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CardsService {

  card: any;

  cards: any[] = [
    { id: 1, cardInfo: "1223 2334 3445 4556", expiration: "06/23", securityCode: "123"}
  ]

  constructor() { }

  getCards() {
    return this.cards;
  }

  getAddressById(id: any) {

    this.card = this.cards.find(card => card.id == id);

    console.log(this.card);

    return this.card;
  }
}
