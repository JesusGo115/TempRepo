import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TrackingInfoService {

  order: any;

  orders: any[] = [
    { id: 1, status: "Placed", time: "21"}
  ]

  constructor() { }

  getOrders() {
    return this.orders;
  }

  getOrdersById(id: any) {

    this.order = this.orders.find(order => order.id == id);

    console.log(this.order);

    return this.order;
  }
}
