import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AddressesService {

  address: any;

  addresses: any[] = [
    { id: 1, name: "John Doe", address: "123 Playground Street"}
  ]

  constructor() { }

  getAddresses() {
    return this.addresses;
  }

  getAddressById(id: any) {

    this.address = this.addresses.find(address => address.id == id);

    console.log(this.address);

    return this.address;
  }
}
