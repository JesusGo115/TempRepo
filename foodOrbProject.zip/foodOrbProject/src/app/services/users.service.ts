import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  user: any;

  users: any[] = [
    { id: 1, name: "John Doe", email: "johnDoe1@google.com", password: "helloo", phoneNo: "8311234567", proff: "Java Developer", profImg: "https://twirpz.files.wordpress.com/2015/06/twitter-avi-gender-balanced-figure.png"}
  ]

  constructor() { }

  getUsers() {
    return this.users;
  }

  getUsersById(id: any) {

    this.user = this.users.find(user => user.id == id);

    console.log(this.user);

    return this.user;
  }

}
